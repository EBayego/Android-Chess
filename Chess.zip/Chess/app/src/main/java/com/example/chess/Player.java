package com.example.chess;

public enum Player {
    WHITE,
    BLACK
}
